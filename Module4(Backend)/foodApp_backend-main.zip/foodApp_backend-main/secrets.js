module.exports={
    JWT_KEY:"rbfywg8374bfuiwebf"
}

//mongodb 
//stripe
//nodemailer


    